# job4j_design

This is a project for junior level.

The following topics will be studied:
1. Maven
2. AssertJ
3. Iterator
4. Generic
5. List
6. Set
7. Map
8. Tree
9. Socket
10. PostgreSQL
11. Create Update Insert
12. Query
13. Outer join
14. JDBC
15. Liquibase
16. Java Memory Model
17. TDD
18. SRP
19. OCP
20. LSP
21. ISP
22. DIP